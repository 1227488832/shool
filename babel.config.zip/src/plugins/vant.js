import Vue from 'vue'
import { Button, Icon, Form, CellGroup, Field, Uploader, Popup,Progress } from 'vant'


Vue.use(Button)
Vue.use(Icon)
Vue.use(Form)
Vue.use(CellGroup)
Vue.use(Field)
Vue.use(Uploader)
Vue.use(Popup)
Vue.use(Progress)







